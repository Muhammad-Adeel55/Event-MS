﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Event_Management_System_A
{
    public partial class Events : Form
    {
        public Events()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            try
            {

                if (textBox1.Text == "" && textBox2.Text == "")

                {
                    MessageBox.Show("Missing Information");
                }

                else if (textBox1.Text == "Adee" && textBox2.Text == "Adeel123")
                {
                    Event obj = new Event();
                    obj.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid crendentials");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
            
        
        }

        private void Resetbtn_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
        }

        private void Crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      

      
    }
}
