﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Event_Management_System_A
{
    public partial class Event : Form
    {
        public Event()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\AL-HAMD\\OneDrive\\index.html\\OneDrive\\Documents\\Event MS.mdf\";Integrated Security=True;Connect Timeout=30");
        //Con.Open();
        private void DisplayEvent()
        {

            Con.Open();
            string query = "SELECT * FROM EventTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            EdataGridView1.DataSource = ds.Tables[0];
            Con.Close();
        }

        int CId = 0;

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || comboBox1.SelectedIndex == -1 || textBox3.Text == "")
                {
                    MessageBox.Show("Missing information");
                }
                else
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO EventTbl(CName,CPhone,Events,Date) VALUES (@CN, @CP, @E, @D",Con);
                    cmd.Parameters.AddWithValue("@CN", textBox1.Text);
                    cmd.Parameters.AddWithValue("@CP", textBox2.Text);
                    cmd.Parameters.AddWithValue("@E", comboBox1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@D", textBox3.Text);
                    cmd.BeginExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Entered Sucessfully");
                    DisplayEvent();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { Con.Close(); }
        }



        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || comboBox1.SelectedIndex == -1 || textBox3.Text == "")
                {
                    MessageBox.Show("Missing information");
                }
                else
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE EventTbl SET CName=@CN,CPhone=@CP,Events=@E,Date=@D where CId=@key", Con);
                    cmd.Parameters.AddWithValue("@CN", textBox1.Text);
                    cmd.Parameters.AddWithValue("@CP", textBox2.Text);
                    cmd.Parameters.AddWithValue("@E", comboBox1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@D", textBox3.Text);
                    cmd.Parameters.AddWithValue("@key", CId);
                    cmd.BeginExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Update Sucessfully");
                    DisplayEvent();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { Con.Close(); }
        }



        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (CId != 0)
                {
                    SqlCommand cmd = new SqlCommand("DELETE EventTbl WHERE CId=@key", Con);
                    Con.Open();
                    cmd.Parameters.AddWithValue("@key", CId);
                    cmd.BeginExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Deleted Sucessfully");
                    DisplayEvent();

                }
                else
                {
                    MessageBox.Show("Please Select Record to delete");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { Con.Close(); }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.SelectedIndex = -1;
            textBox3.Text = "";
        }





        private void label6_Click(object sender, EventArgs e)
        {
            Event obj = new Event();
            obj.Show();
            this.Hide();
        }


        private void label7_Click(object sender, EventArgs e)
        {
            Catering obj = new Catering();
            obj.Show();
            this.Hide();
        }


        private void label8_Click(object sender, EventArgs e)
        {
            Cost obj = new Cost();
            obj.Show();
            this.Hide();
        }


        private void label9_Click(object sender, EventArgs e)
        {
            Reviews obj = new Reviews();
            obj.Show();
            this.Hide();
        }


        private void label10_Click(object sender, EventArgs e)
        {
            Events obj = new Events();
            obj.Show();
            this.Hide();
        }


        private void Crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void EdataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (EdataGridView1.CurrentRow.Index != 1)

            {
                CId = Convert.ToInt32(EdataGridView1.CurrentRow.Cells[0].Value.ToString());

                textBox1.Text = EdataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox2.Text = EdataGridView1.CurrentRow.Cells[2].Value.ToString();

                int selectedIndex;
                if (int.TryParse(EdataGridView1.CurrentRow.Cells[3].Value.ToString(), out selectedIndex))
                {
                    comboBox1.SelectedIndex = selectedIndex;
                }
              
                textBox3.Text = EdataGridView1.CurrentRow.Cells[4].Value.ToString();
            }
        }

        private void Event_Load(object sender, EventArgs e)
        {

        }
    }
}

