﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Event_Management_System_A
{
    public partial class Catering : Form
    {
        public Catering()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection( "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\AL-HAMD\\OneDrive\\index.html\\OneDrive\\Documents\\Event MS.mdf\";Integrated Security=True;Connect Timeout=30 ");
        private void DisplayCatering()
        {

           
        }

        

        int FoodId;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedIndex == -1 || comboBox2.SelectedIndex == -1)
                {
                    MessageBox.Show("Missing information");
                }
                else
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO CateringTbl(CustomerId,Food) values (@CN, @F)",Con);
                    cmd.Parameters.AddWithValue("@CN", comboBox1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@F", comboBox2.SelectedValue.ToString());
                    cmd.BeginExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Entered Sucessfully");
                    DisplayCatering();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { Con.Close(); }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedIndex == -1 || comboBox2.SelectedIndex == -1)
                {
                    MessageBox.Show("Missing information");
                }
                else
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("UPADET Catering Tbl SET CustomerId=@CN ,Food=@ WHERE FoodId=@key", Con);
                    cmd.Parameters.AddWithValue("@CN", comboBox1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@F", comboBox2.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@key", FoodId);
                    cmd.BeginExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Update Sucessfully");
                    DisplayCatering();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { Con.Close(); }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (FoodId != 0)
                {
                    SqlCommand cmd = new SqlCommand("DELETE Catering Tbl WHERE FoodId=@key", Con);
                    Con.Open();
                    cmd.Parameters.AddWithValue("@key", FoodId);
                    cmd.BeginExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Deleted Sucessfully");
                    DisplayCatering();

                }
                else
                {
                    MessageBox.Show("Please Select Record To Delete");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { Con.Close(); }
        }



        private void button4_Click(object sender, EventArgs e)
        {
            comboBox2.SelectedIndex = -1;
            comboBox1.SelectedIndex = -1;
        }


        private void CdataGridView1_DoubleClick(object sender, EventArgs e)
        {

           
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Event obj = new Event();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Catering obj = new Catering();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Cost obj = new Cost();
            obj.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Reviews obj = new Reviews();
            obj.Show();
            this.Hide();
        }

        private void Crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Events obj = new Events();
            obj.Show();
            this.Hide();
        }
    }
}
